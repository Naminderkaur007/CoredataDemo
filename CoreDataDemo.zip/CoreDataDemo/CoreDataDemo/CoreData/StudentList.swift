//
//  StudentList.swift
//  AbcDemo
//
//  Created by naminderkaur on 13/04/20.
//  Copyright © 2020 naminderkaur. All rights reserved.
//

import UIKit
import CoreData

class StudentList: UIViewController,UITableViewDataSource,UITableViewDelegate{
    
    var getCollegeInfo : CollegeName?
    @IBOutlet weak var tblStudentList: UITableView!
    @IBOutlet weak var actionStudentAdd: UIBarButtonItem!
    var arrayOfStudentList  : [StudentRecord] = []{
               didSet{
                print("data")
                   self.tblStudentList.reloadData()
               }
           }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tblStudentList.delegate = self
        self.tblStudentList.dataSource = self
        self.retrieveData()
        self.tblStudentList.tableFooterView = UIView()


    }
    
    func retrieveData() {
                    
    if getCollegeInfo?.students?.allObjects != nil{
        arrayOfStudentList = getCollegeInfo?.students?.allObjects as![StudentRecord]
        }
                
    }

    @IBAction func actionAddStudentListSubmit(_ sender: Any) {
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "StudentForm") as! StudentForm

           secondViewController.getCollegeInfo = getCollegeInfo
                   self.navigationController?.pushViewController(secondViewController, animated: true)
        
    }
    
   
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
              
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "StudentDetail") as! StudentDetail
        secondViewController.getStudentInfo = arrayOfStudentList[indexPath.row] as! StudentRecord
        self.navigationController?.pushViewController(secondViewController, animated: true)


        
           }
           
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
               
               let dict = arrayOfStudentList[indexPath.row] as! StudentRecord
               let name = dict.studentname
               
               arrayOfStudentList.remove(at: indexPath.row)
               self.deleteData(name: name!)
           }
           
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
       {
           
      let cell = tableView.dequeueReusableCell(withIdentifier: StudentCell.reuseIdentifier, for: indexPath)
               configure(cell: cell, indexPath: indexPath)
               
               return cell
           }
           
           func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
               return arrayOfStudentList.count
           }
           private func configure(cell: UITableViewCell, indexPath: IndexPath) {
               
               if let cell : StudentCell = cell as? StudentCell {
               
               let dict = arrayOfStudentList[indexPath.row] as! StudentRecord
                cell.lblStudentname.text = dict.studentname
                cell.lblAge.text = dict.age
                cell.lblQualification.text = dict.qualification
                cell.lblAddress.text = dict.address
              //  cell.imgStudent.image = UIImage(data: dict.studentimage!)
                cell.lblCollegeName.text = dict.universities?.collegename!
                
               }
               
           }
       
    
    func deleteData(name : String){
        
        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
        let managedContext = appDelegate.persistentContainer.viewContext
        
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "StudentRecord")
        fetchRequest.predicate = NSPredicate(format: "studentname = %@", name)
        do
        {
            let test = try managedContext.fetch(fetchRequest)
            let objectToDelete = test[0] as! NSManagedObject
            managedContext.delete(objectToDelete)
            
            do{
                try managedContext.save()
            }
            catch
            {
                print(error)
            }
            
        }
        catch
        {
            print(error)
        }
    }
    
    
}
