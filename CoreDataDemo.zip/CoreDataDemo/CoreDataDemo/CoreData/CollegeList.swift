    

import UIKit
import CoreData

    class CollegeList : UIViewController ,UITableViewDataSource,UITableViewDelegate{
        
        var collegeDetail: CollegeName?
        var refreshControl = UIRefreshControl()

       
        @IBOutlet weak var tblCollegeList: UITableView!{
            willSet{
                
            }
            didSet{
                print("Table College list")
                
            }
        }
        var arrayOfCollegeList  : [CollegeName] = []{
            didSet{
                self.tblCollegeList.reloadData()
            }
        }
    
        
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            print("s")
            let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "CollegeDetail") as! CollegeDetail
            secondViewController.getCollegeInfo = arrayOfCollegeList[indexPath.row] as! CollegeName
            self.navigationController?.pushViewController(secondViewController, animated: true)

        }
        
        
        
        
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            
            let dict = arrayOfCollegeList[indexPath.row] as! CollegeName
            let name = dict.collegename
            
            arrayOfCollegeList.remove(at: indexPath.row)
            self.deleteData(name: name!)
        }
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
   let cell = tableView.dequeueReusableCell(withIdentifier: CollegeListCell.reuseIdentifier, for: indexPath)
            configure(cell: cell, indexPath: indexPath)
            
            return cell
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return arrayOfCollegeList.count
        }
        private func configure(cell: UITableViewCell, indexPath: IndexPath) {
            
            if let cell : CollegeListCell = cell as? CollegeListCell {
            
            let dict = arrayOfCollegeList[indexPath.row] as! CollegeName
                cell.lblCollegeName.text = dict.collegename
                cell.lblState.text = dict.state
                cell.lblPincode.text = dict.pincode
                cell.lblLandmark.text = dict.landmark
            }
            
        }
    
        @objc func studentform(){
            print("student add")
        let secondViewController = self.storyboard?.instantiateViewController(withIdentifier: "StudentList") as! StudentList
            self.navigationController?.pushViewController(secondViewController, animated: true)

        }
        func retrieveData() {
                
                
                guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
                
                
                let managedContext = appDelegate.persistentContainer.viewContext
                
                
                let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CollegeName")
                
                do {
                    let result = try managedContext.fetch(fetchRequest) as! [CollegeName]
                    arrayOfCollegeList = result

                    
                } catch {
                    
                    print("Failed")
                }
            }
            
        func deleteData(name : String){
       
       //As we know that container is set up in the AppDelegates so we need to refer that container.
       guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
       
       //We need to create a context from this container
       let managedContext = appDelegate.persistentContainer.viewContext
       
       let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "CollegeName")
       fetchRequest.predicate = NSPredicate(format: "collegename = %@", name)
       do
       {
           let test = try managedContext.fetch(fetchRequest)
           let objectToDelete = test[0] as! NSManagedObject
           managedContext.delete(objectToDelete)
           
           do{
               try managedContext.save()
           }
           catch
           {
               print(error)
           }
           
       }
       catch
       {
           print(error)
       }
   }
   
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        refreshControl.attributedTitle = NSAttributedString(string: "Pull to refresh")
        refreshControl.addTarget(self, action: #selector(self.refresh(_:)), for: .valueChanged)
        self.tblCollegeList.addSubview(refreshControl)
        
        
    }
        
        
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tblCollegeList.delegate = self
        self.tblCollegeList.dataSource = self
        self.retrieveData()
        self.tblCollegeList.tableFooterView = UIView()

    }
    
    
        @objc func refresh(_ sender: AnyObject) {
           // Code to refresh table view
            refreshControl.endRefreshing()

        }
        
    
        @IBAction func actionCollegeForm(_ sender: Any) {
            
            let collegeForm = self.storyboard?.instantiateViewController(withIdentifier: "CollegeForm") as! CollegeForm
            self.navigationController?.pushViewController(collegeForm, animated: true)

             }
        
   
    
    }
