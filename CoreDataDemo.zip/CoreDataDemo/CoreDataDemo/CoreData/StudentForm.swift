//
//  StudentForm.swift
//  AbcDemo
//
//  Created by naminderkaur on 13/04/20.
//  Copyright © 2020 naminderkaur. All rights reserved.
//

import UIKit
import CoreData


class StudentForm: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    
    @IBOutlet weak var imgStudent: UIImageView!
    @IBOutlet weak var btnSelectPhoto: UIButton!
    @IBOutlet weak var txtStudentName: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var txtQualification: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtSubmit: UIButton!
    
    var getCollegeInfo : CollegeName?
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        print(getCollegeInfo)
        
    }
    
    func studentFormSubmit(){

        guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
                       
                       let managedContext = appDelegate.persistentContainer.viewContext
                       
                       let userEntity = NSEntityDescription.insertNewObject(forEntityName: "StudentRecord", into: managedContext) as! StudentRecord
               
               userEntity.studentname = self.txtStudentName.text
               userEntity.qualification = self.txtQualification.text
               userEntity.age = self.txtAge.text
               userEntity.address = self.txtAddress.text
               userEntity.universities = getCollegeInfo
        if let data = (self.imgStudent.image ?? UIImage()).pngData(){
                   userEntity.studentimage = data
               }
                       
                       do {
                           try managedContext.save()
                           print("Successfully saved data")
                         
                           let alert = UIAlertController(title: "Student Form", message: "Data Saved Successfully", preferredStyle: .alert)
                           
                           alert.addAction(UIAlertAction(title: "OK", style: .default, handler: { action in

                              print("ok then")
                               self.txtStudentName.text = ""
                               self.txtQualification.text = ""
                               self.txtAge.text = ""
                               self.txtAddress.text = ""
                               
                           }))
                           self.present(alert, animated: true)
                           
                          
                       } catch let error as NSError {
                           print("Could not save. \(error), \(error.userInfo)")
                       }
               
    }
    
    
    @IBAction func actionSelectPhoto(_ sender: Any) {
        
        let imagecontrollr = UIImagePickerController()
               imagecontrollr.delegate = self
        imagecontrollr.sourceType = UIImagePickerController.SourceType.photoLibrary
               self.present(imagecontrollr,animated: true, completion: nil)

    }
    
  /*  func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
           
        self.imgStudent.image = info[UIImagePickerController.InfoKey.originalImage.rawValue]as? UIImage
           self.dismiss(animated: true, completion: nil)
           print("hello")
       }
    */
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
          
          if let pickedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage {
                 self.imgStudent.contentMode = .scaleAspectFit
                 self.imgStudent.image = pickedImage
             }
          
             dismiss(animated: true, completion: nil)
      }
    
    
    @IBAction func btnActionSubmitForm(_ sender: Any) {
        
        self.studentFormSubmit()
              
     }
    
    
    }
    
   

