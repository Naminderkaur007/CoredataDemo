//
//  StudentDetail.swift
//  AbcDemo
//
//  Created by naminderkaur on 14/04/20.
//  Copyright © 2020 naminderkaur. All rights reserved.
//

import UIKit
import CoreData

class StudentDetail: UIViewController {

    
    var getStudentInfo : StudentRecord?

    
    @IBOutlet weak var lblStudentName: UILabel!
    @IBOutlet weak var lblAge: UILabel!
    @IBOutlet weak var lblQualification: UILabel!
    @IBOutlet weak var lblAddress: UILabel!
    @IBOutlet weak var imgStudent: UIImageView!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(getStudentInfo)
             
             self.lblStudentName.text = getStudentInfo?.studentname!
             self.lblAge.text = getStudentInfo?.age!
             self.lblQualification.text = getStudentInfo?.qualification!
             self.lblAddress.text = getStudentInfo?.address!
             self.imgStudent.image = UIImage(data: (getStudentInfo?.studentimage!)!)
        

    }
    
    
    func fetchDetail(){
        
        
    }
    
    
    @IBAction func actionEditStudent(_ sender: Any) {
        
        let editPage = self.storyboard?.instantiateViewController(withIdentifier: "StudentEditDetail") as! StudentEditDetail
        editPage.getStudentInfo = getStudentInfo
        self.navigationController?.pushViewController(editPage, animated: true)

    }
    
    
    
}
