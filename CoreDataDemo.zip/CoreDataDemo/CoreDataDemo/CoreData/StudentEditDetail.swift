//
//  StudentEditDetail.swift
//  AbcDemo
//
//  Created by naminderkaur on 14/04/20.
//  Copyright © 2020 naminderkaur. All rights reserved.
//

import UIKit

class StudentEditDetail: UIViewController,UIImagePickerControllerDelegate,UINavigationControllerDelegate {

    var getStudentInfo : StudentRecord?

    
    @IBOutlet weak var imgStudent: UIImageView!
    @IBOutlet weak var txtStudentName: UITextField!
    @IBOutlet weak var txtAge: UITextField!
    @IBOutlet weak var txtQualification: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var btnSubmit: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
             self.txtStudentName.text = getStudentInfo?.studentname!
             self.txtAge.text = getStudentInfo?.age!
             self.txtQualification.text = getStudentInfo?.qualification!
             self.txtAddress.text = getStudentInfo?.address!
             self.imgStudent.image = UIImage(data: (getStudentInfo?.studentimage!)!)
        
    }
    
    @IBAction func actionEditForm(_ sender: Any) {
        
        print("work in progress")
    }
   /* func updateData(){
       
           //As we know that container is set up in the AppDelegates so we need to refer that container.
           guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
           
           //We need to create a context from this container
           let managedContext = appDelegate.persistentContainer.viewContext
           
           let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest.init(entityName: "User")
           fetchRequest.predicate = NSPredicate(format: "username = %@", "Naminder1")
           do
           {
               let test = try managedContext.fetch(fetchRequest)
      
                   let objectUpdate = test[0] as! NSManagedObject
                   objectUpdate.setValue("newName", forKey: "username")
                   objectUpdate.setValue("newmail", forKey: "email")
                   objectUpdate.setValue("newpassword", forKey: "password")
                   do{
                       try managedContext.save()
                   }
                   catch
                   {
                       print(error)
                   }
               }
           catch
           {
               print(error)
           }
      
       }*/
    
    
}
